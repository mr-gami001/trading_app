import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/market_feed/market_feed_bloc.dart';
import '../blocs/market_feed/market_feed_event.dart';
import '../blocs/market_feed/market_feed_state.dart';
import '../widgets/stock_row_tile.dart';
import 'buy_sell_ticket_screen.dart';

class LivePricesScreen extends StatelessWidget {
  const LivePricesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.bolt, color: Color(0xFFF59E0B)),
            SizedBox(width: 8),
            Text(
              'Live Market Overview',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Configurable Tick Rate Controller & Stress Mode Banner
          BlocBuilder<MarketFeedBloc, MarketFeedState>(
            builder: (context, state) {
              final bloc = context.read<MarketFeedBloc>();

              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: const BoxDecoration(
                  color: Color(0xFF1E293B),
                  border: Border(bottom: BorderSide(color: Color(0xFF334155))),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.tune, color: Color(0xFF3B82F6), size: 18),
                            const SizedBox(width: 6),
                            Text(
                              'Feed Interval: ${state.tickIntervalMs} ms',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            const Text(
                              'Stress Mode (50+ ticks/s)',
                              style: TextStyle(
                                color: Color(0xFFEF4444),
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                            Switch(
                              value: state.isStressMode,
                              activeTrackColor: const Color(0xFFEF4444),
                              onChanged: (val) {
                                bloc.add(ToggleStressModeEvent(val));
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        const Text('Slow (2s)', style: TextStyle(color: Color(0xFF64748B), fontSize: 11)),
                        Expanded(
                          child: Slider(
                            value: state.tickIntervalMs.toDouble(),
                            min: 20.0,
                            max: 2000.0,
                            divisions: 99,
                            activeColor: state.isStressMode ? const Color(0xFFEF4444) : const Color(0xFF3B82F6),
                            onChanged: (val) {
                              bloc.add(SetTickIntervalEvent(val.toInt()));
                            },
                          ),
                        ),
                        const Text('Fast (20ms)', style: TextStyle(color: Color(0xFF64748B), fontSize: 11)),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Total Ticks Generated: ${state.totalTicksCount}',
                            style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 11),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF10B981).withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.circle, color: Color(0xFF10B981), size: 8),
                                SizedBox(width: 4),
                                Text(
                                  'LIVE FEED ACTIVE',
                                  style: TextStyle(color: Color(0xFF10B981), fontSize: 10, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),

          // 10 Stocks List View
          Expanded(
            child: ListView.builder(
              itemCount: MarketFeedBloc.initialUniverse.length,
              itemBuilder: (context, index) {
                final stock = MarketFeedBloc.initialUniverse[index];
                return StockRowTile(
                  key: ValueKey('live_feed_${stock.symbol}'),
                  symbol: stock.symbol,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => BuySellTicketScreen(initialSymbol: stock.symbol),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
