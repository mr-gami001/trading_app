import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/watchlist/watchlist_bloc.dart';
import '../blocs/watchlist/watchlist_event.dart';
import '../blocs/watchlist/watchlist_state.dart';
import '../widgets/stock_row_tile.dart';
import '../widgets/add_stock_modal.dart';
import 'buy_sell_ticket_screen.dart';

class WatchlistScreen extends StatelessWidget {
  const WatchlistScreen({super.key});

  void _showCreateWatchlistDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Create New Watchlist', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Watchlist Name (e.g. IT Stocks)',
            hintStyle: TextStyle(color: Color(0xFF64748B)),
            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF334155))),
            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF3B82F6))),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF94A3B8))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF3B82F6)),
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) {
                context.read<WatchlistBloc>().add(CreateWatchlistEvent(name));
                Navigator.of(ctx).pop();
              }
            },
            child: const Text('Create', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showRenameDialog(BuildContext context, String watchlistId, String currentName) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Rename Watchlist', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Watchlist Name',
            hintStyle: TextStyle(color: Color(0xFF64748B)),
            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF334155))),
            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF3B82F6))),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF94A3B8))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF3B82F6)),
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) {
                context.read<WatchlistBloc>().add(RenameWatchlistEvent(watchlistId, name));
                Navigator.of(ctx).pop();
              }
            },
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WatchlistBloc, WatchlistState>(
      builder: (context, state) {
        final activeWl = state.activeWatchlist;
        final bloc = context.read<WatchlistBloc>();

        return Scaffold(
          backgroundColor: const Color(0xFF0F172A),
          appBar: AppBar(
            backgroundColor: const Color(0xFF1E293B),
            elevation: 0,
            title: const Row(
              children: [
                Icon(Icons.show_chart, color: Color(0xFF3B82F6)),
                SizedBox(width: 8),
                Text(
                  'Watchlists',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.add, color: Colors.white),
                tooltip: 'Create Watchlist',
                onPressed: () => _showCreateWatchlistDialog(context),
              ),
            ],
          ),
          body: state.isLoading
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    // Watchlist Selector Bar
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      color: const Color(0xFF1E293B),
                      child: Row(
                        children: [
                          Expanded(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: List.generate(state.watchlists.length, (index) {
                                  final wl = state.watchlists[index];
                                  final isSelected = index == state.activeWatchlistIndex;

                                  return Padding(
                                    padding: const EdgeInsets.only(right: 8.0),
                                    child: ChoiceChip(
                                      label: Text(wl.name),
                                      selected: isSelected,
                                      selectedColor: const Color(0xFF3B82F6),
                                      backgroundColor: const Color(0xFF0F172A),
                                      labelStyle: TextStyle(
                                        color: isSelected ? Colors.white : const Color(0xFF94A3B8),
                                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                      ),
                                      onSelected: (_) => bloc.add(SetActiveWatchlistIndexEvent(index)),
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ),
                          if (activeWl != null) ...[
                            PopupMenuButton<String>(
                              icon: const Icon(Icons.more_vert, color: Color(0xFF94A3B8)),
                              color: const Color(0xFF1E293B),
                              onSelected: (value) {
                                if (value == 'rename') {
                                  _showRenameDialog(context, activeWl.id, activeWl.name);
                                } else if (value == 'delete') {
                                  bloc.add(DeleteWatchlistEvent(activeWl.id));
                                }
                              },
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 'rename',
                                  child: Row(
                                    children: [
                                      Icon(Icons.edit, color: Colors.white, size: 18),
                                      SizedBox(width: 8),
                                      Text('Rename', style: TextStyle(color: Colors.white)),
                                    ],
                                  ),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Row(
                                    children: [
                                      Icon(Icons.delete_outline, color: Color(0xFFEF4444), size: 18),
                                      SizedBox(width: 8),
                                      Text('Delete', style: TextStyle(color: Color(0xFFEF4444))),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),

                    // Stock List or Empty State
                    Expanded(
                      child: activeWl == null || activeWl.symbols.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.playlist_add, size: 64, color: Color(0xFF475569)),
                                  const SizedBox(height: 16),
                                  const Text(
                                    'This watchlist is empty',
                                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'Add stocks to track live prices in real time',
                                    style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                                  ),
                                  const SizedBox(height: 20),
                                  ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF3B82F6),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                    ),
                                    icon: const Icon(Icons.add, color: Colors.white),
                                    label: const Text('Add Stock', style: TextStyle(color: Colors.white)),
                                    onPressed: () {
                                      if (activeWl != null) {
                                        showModalBottomSheet(
                                          context: context,
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          builder: (ctx) => AddStockModal(watchlistId: activeWl.id),
                                        );
                                      }
                                    },
                                  ),
                                ],
                              ),
                            )
                          : ReorderableListView.builder(
                              itemCount: activeWl.symbols.length,
                              onReorder: (oldIndex, newIndex) {
                                bloc.add(ReorderStockEvent(activeWl.id, oldIndex, newIndex));
                              },
                              itemBuilder: (context, index) {
                                final symbol = activeWl.symbols[index];
                                return Dismissible(
                                  key: ValueKey('wl_${activeWl.id}_$symbol'),
                                  direction: DismissDirection.endToStart,
                                  background: Container(
                                    alignment: Alignment.centerRight,
                                    padding: const EdgeInsets.only(right: 20),
                                    color: const Color(0xFFEF4444),
                                    child: const Icon(Icons.delete, color: Colors.white),
                                  ),
                                  onDismissed: (_) {
                                    bloc.add(RemoveStockFromWatchlistEvent(activeWl.id, symbol));
                                  },
                                  child: StockRowTile(
                                    key: ValueKey('stock_tile_$symbol'),
                                    symbol: symbol,
                                    isReorderable: true,
                                    onTap: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => BuySellTicketScreen(initialSymbol: symbol),
                                        ),
                                      );
                                    },
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
          floatingActionButton: activeWl != null && activeWl.symbols.isNotEmpty
              ? FloatingActionButton(
                  backgroundColor: const Color(0xFF3B82F6),
                  child: const Icon(Icons.add, color: Colors.white),
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (ctx) => AddStockModal(watchlistId: activeWl.id),
                    );
                  },
                )
              : null,
        );
      },
    );
  }
}
