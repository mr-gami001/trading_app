import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/market_feed/market_feed_bloc.dart';
import '../blocs/market_feed/market_feed_state.dart';
import '../blocs/portfolio/portfolio_bloc.dart';
import '../blocs/portfolio/portfolio_event.dart';
import '../blocs/portfolio/portfolio_state.dart';
import '../models/stock_quote.dart';
import '../models/trade_order.dart';
import '../utils/formatters.dart';

class BuySellTicketScreen extends StatefulWidget {
  final String initialSymbol;
  final OrderSide initialSide;

  const BuySellTicketScreen({
    super.key,
    required this.initialSymbol,
    this.initialSide = OrderSide.buy,
  });

  @override
  State<BuySellTicketScreen> createState() => _BuySellTicketScreenState();
}

class _BuySellTicketScreenState extends State<BuySellTicketScreen> {
  late String _selectedSymbol;
  late OrderSide _side;
  final TextEditingController _quantityController = TextEditingController(text: '1');

  String? _errorMessage;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _selectedSymbol = widget.initialSymbol;
    _side = widget.initialSide;
  }

  @override
  void dispose() {
    _quantityController.dispose();
    super.dispose();
  }

  void _validateAndSubmit(StockQuote quote, PortfolioState portfolioState) async {
    setState(() {
      _errorMessage = null;
    });

    final String text = _quantityController.text.trim();
    final int? quantity = int.tryParse(text);

    if (quantity == null || quantity <= 0) {
      setState(() {
        _errorMessage = 'Please enter a valid positive integer quantity';
      });
      return;
    }

    final double totalOrderValue = double.parse((quantity * quote.ltp).toStringAsFixed(2));

    if (_side == OrderSide.buy) {
      if (portfolioState.walletBalance < totalOrderValue) {
        setState(() {
          _errorMessage =
              'Insufficient funds. Order Value: ${Formatters.currency(totalOrderValue)}, Available: ${Formatters.currency(portfolioState.walletBalance)}';
        });
        return;
      }
    } else {
      final holding = portfolioState.getHoldingForSymbol(_selectedSymbol);
      if (holding == null || holding.quantity < quantity) {
        final heldQty = holding?.quantity ?? 0;
        setState(() {
          _errorMessage = 'Insufficient quantity held. You currently hold $heldQty shares of $_selectedSymbol';
        });
        return;
      }
    }

    setState(() {
      _isSubmitting = true;
    });

    final completer = Completer<String?>();
    context.read<PortfolioBloc>().add(
          PlaceOrderEvent(
            symbol: _selectedSymbol,
            side: _side,
            quantity: quantity,
            ltp: quote.ltp,
            completer: completer,
          ),
        );

    final error = await completer.future;

    setState(() {
      _isSubmitting = false;
    });

    if (error != null) {
      setState(() {
        _errorMessage = error;
      });
    } else {
      if (!mounted) return;
      _showConfirmationDialog(quantity, quote.ltp, totalOrderValue);
    }
  }

  void _showConfirmationDialog(int quantity, double price, double totalValue) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(
              _side == OrderSide.buy ? Icons.check_circle : Icons.sell,
              color: _side == OrderSide.buy ? const Color(0xFF10B981) : const Color(0xFF3B82F6),
              size: 28,
            ),
            const SizedBox(width: 10),
            Text(
              '${_side == OrderSide.buy ? "BUY" : "SELL"} Executed!',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Stock', _selectedSymbol),
            _buildDetailRow('Quantity', '$quantity shares'),
            _buildDetailRow('Executed Price', Formatters.currency(price)),
            const Divider(color: Color(0xFF334155)),
            _buildDetailRow('Total Amount', Formatters.currency(totalValue), isBold: true),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B82F6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Done', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isBuy = _side == OrderSide.buy;
    final primaryColor = isBuy ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        elevation: 0,
        title: Text(
          'Trade $_selectedSymbol',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Stock Selector Dropdown
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _selectedSymbol,
                        dropdownColor: const Color(0xFF1E293B),
                        icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                        items: MarketFeedBloc.initialUniverse.map((stock) {
                          return DropdownMenuItem<String>(
                            value: stock.symbol,
                            child: Text(
                              '${stock.symbol} - ${stock.name}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) {
                            setState(() {
                              _selectedSymbol = val;
                              _errorMessage = null;
                            });
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Live Price & Form Tile via BlocSelector
            BlocSelector<MarketFeedBloc, MarketFeedState, StockQuote?>(
              selector: (state) => state.quotes[_selectedSymbol],
              builder: (context, quote) {
                if (quote == null) return const SizedBox.shrink();

                return BlocBuilder<PortfolioBloc, PortfolioState>(
                  builder: (context, portfolioState) {
                    final int qty = int.tryParse(_quantityController.text.trim()) ?? 0;
                    final double estimatedTotal = double.parse((qty * quote.ltp).toStringAsFixed(2));

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // LTP Banner
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Live Price (LTP)',
                                    style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    Formatters.currency(quote.ltp),
                                    style: TextStyle(
                                      color: quote.change >= 0 ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  const Text(
                                    'Day Change',
                                    style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    Formatters.priceChange(quote.change, quote.changePercent),
                                    style: TextStyle(
                                      color: quote.change >= 0 ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Buy / Sell Side Selector Toggle
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  onTap: () => setState(() {
                                    _side = OrderSide.buy;
                                    _errorMessage = null;
                                  }),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      color: isBuy ? const Color(0xFF10B981) : Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        'BUY',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () => setState(() {
                                    _side = OrderSide.sell;
                                    _errorMessage = null;
                                  }),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      color: !isBuy ? const Color(0xFFEF4444) : Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        'SELL',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // Input Quantity Field
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Quantity',
                                style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  IconButton(
                                    onPressed: () {
                                      final current = int.tryParse(_quantityController.text) ?? 1;
                                      if (current > 1) {
                                        _quantityController.text = (current - 1).toString();
                                        setState(() {});
                                      }
                                    },
                                    icon: const Icon(Icons.remove_circle_outline, color: Colors.white),
                                  ),
                                  Expanded(
                                    child: TextField(
                                      controller: _quantityController,
                                      keyboardType: TextInputType.number,
                                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      decoration: const InputDecoration(
                                        border: InputBorder.none,
                                        hintText: 'Qty',
                                        hintStyle: TextStyle(color: Color(0xFF64748B)),
                                      ),
                                      onChanged: (_) => setState(() => _errorMessage = null),
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      final current = int.tryParse(_quantityController.text) ?? 0;
                                      _quantityController.text = (current + 1).toString();
                                      setState(() {});
                                    },
                                    icon: const Icon(Icons.add_circle_outline, color: Colors.white),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Order Summary & Balance Check Info
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E293B),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Projected Order Value', style: TextStyle(color: Color(0xFF94A3B8))),
                                  Text(
                                    Formatters.currency(estimatedTotal),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isBuy ? 'Available Wallet Balance' : 'Shares Currently Held',
                                    style: const TextStyle(color: Color(0xFF94A3B8)),
                                  ),
                                  Text(
                                    isBuy
                                        ? Formatters.currency(portfolioState.walletBalance)
                                        : '${portfolioState.getHoldingForSymbol(_selectedSymbol)?.quantity ?? 0} shares',
                                    style: TextStyle(
                                      color: isBuy && portfolioState.walletBalance < estimatedTotal
                                          ? const Color(0xFFEF4444)
                                          : Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Inline Error Banner
                        if (_errorMessage != null)
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0x22EF4444),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: const Color(0xFFEF4444)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 20),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    _errorMessage!,
                                    style: const TextStyle(color: Color(0xFFEF4444), fontSize: 13),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        const SizedBox(height: 24),

                        // Submit Button
                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: _isSubmitting ? null : () => _validateAndSubmit(quote, portfolioState),
                            child: _isSubmitting
                                ? const SizedBox(
                                    height: 24,
                                    width: 24,
                                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                  )
                                : Text(
                                    'Submit ${isBuy ? "BUY" : "SELL"} Order',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
