import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/market_feed/market_feed_bloc.dart';
import '../blocs/market_feed/market_feed_state.dart';
import '../blocs/portfolio/portfolio_bloc.dart';
import '../blocs/portfolio/portfolio_event.dart';
import '../blocs/portfolio/portfolio_state.dart';
import '../utils/formatters.dart';
import 'buy_sell_ticket_screen.dart';

class HoldingsScreen extends StatelessWidget {
  const HoldingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MarketFeedBloc, MarketFeedState>(
      builder: (context, feedState) {
        return BlocBuilder<PortfolioBloc, PortfolioState>(
          builder: (context, portfolioState) {
            final quotes = feedState.quotes;
            final holdings = portfolioState.getSortedHoldings(quotes);
            final totalInvested = portfolioState.getTotalInvested();
            final totalCurrentValue = portfolioState.getTotalCurrentValue(quotes);
            final totalPnl = portfolioState.getTotalPnl(quotes);
            final totalPnlPct = portfolioState.getTotalPnlPercent(quotes);
            final isPnlPositive = totalPnl >= 0;
            final pnlColor = isPnlPositive ? const Color(0xFF10B981) : const Color(0xFFEF4444);

            return Scaffold(
              backgroundColor: const Color(0xFF0F172A),
              appBar: AppBar(
                backgroundColor: const Color(0xFF1E293B),
                elevation: 0,
                title: const Row(
                  children: [
                    Icon(Icons.pie_chart, color: Color(0xFF10B981)),
                    SizedBox(width: 8),
                    Text(
                      'Portfolio & Holdings',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              body: portfolioState.isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : Column(
                      children: [
                        // Portfolio Aggregate Summary Card
                        Container(
                          margin: const EdgeInsets.all(16),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: const Color(0xFF334155)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.3),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Invested Value',
                                        style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        Formatters.currency(totalInvested),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      const Text(
                                        'Current Value',
                                        style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        Formatters.currency(totalCurrentValue),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 12),
                                child: Divider(color: Color(0xFF334155)),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Total P&L',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        Formatters.currency(totalPnl),
                                        style: TextStyle(
                                          color: pnlColor,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: pnlColor.withValues(alpha: 0.2),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          '${isPnlPositive ? "+" : ""}${totalPnlPct.toStringAsFixed(2)}%',
                                          style: TextStyle(
                                            color: pnlColor,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        // Filter / Sort Options Bar
                        if (holdings.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Holdings (${holdings.length})',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                Row(
                                  children: [
                                    const Text('Sort by: ', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
                                    DropdownButtonHideUnderline(
                                      child: DropdownButton<HoldingSortOption>(
                                        value: portfolioState.sortOption,
                                        dropdownColor: const Color(0xFF1E293B),
                                        style: const TextStyle(color: Color(0xFF3B82F6), fontWeight: FontWeight.bold, fontSize: 12),
                                        icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF3B82F6)),
                                        items: const [
                                          DropdownMenuItem(
                                            value: HoldingSortOption.pnlDesc,
                                            child: Text('P&L (High to Low)'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.pnlAsc,
                                            child: Text('P&L (Low to High)'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.currentValueDesc,
                                            child: Text('Current Value'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.symbolAsc,
                                            child: Text('Symbol (A-Z)'),
                                          ),
                                        ],
                                        onChanged: (val) {
                                          if (val != null) {
                                            context.read<PortfolioBloc>().add(SetHoldingSortOptionEvent(val));
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                        // Holdings List or Empty State
                        Expanded(
                          child: holdings.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(Icons.account_balance_wallet_outlined, size: 64, color: Color(0xFF475569)),
                                      const SizedBox(height: 16),
                                      const Text(
                                        'No holdings in your portfolio',
                                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                                      ),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Buy stocks from the Watchlist or Market Feed to start',
                                        style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                                      ),
                                    ],
                                  ),
                                )
                              : ListView.builder(
                                  itemCount: holdings.length,
                                  itemBuilder: (context, index) {
                                    final holding = holdings[index];
                                    final quote = quotes[holding.symbol];
                                    final double currentLtp = quote?.ltp ?? holding.avgCost;
                                    final double holdingPnl = holding.pnl(currentLtp);
                                    final double holdingPnlPct = holding.pnlPercent(currentLtp);
                                    final bool isPos = holdingPnl >= 0;
                                    final Color color = isPos ? const Color(0xFF10B981) : const Color(0xFFEF4444);

                                    return Container(
                                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF1E293B),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: const Color(0xFF334155)),
                                      ),
                                      child: Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          borderRadius: BorderRadius.circular(12),
                                          onTap: () {
                                            Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) => BuySellTicketScreen(initialSymbol: holding.symbol),
                                              ),
                                            );
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(14.0),
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Text(
                                                          holding.symbol,
                                                          style: const TextStyle(
                                                            color: Colors.white,
                                                            fontWeight: FontWeight.bold,
                                                            fontSize: 16,
                                                          ),
                                                        ),
                                                        const SizedBox(width: 8),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xFF334155),
                                                            borderRadius: BorderRadius.circular(4),
                                                          ),
                                                          child: Text(
                                                            'Qty: ${holding.quantity}',
                                                            style: const TextStyle(color: Color(0xFFCBD5E1), fontSize: 11),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Text(
                                                      Formatters.currency(holdingPnl),
                                                      style: TextStyle(
                                                        color: color,
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 10),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        const Text('Avg. Cost', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          Formatters.currency(holding.avgCost),
                                                          style: const TextStyle(color: Colors.white, fontSize: 13),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        const Text('LTP', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          Formatters.currency(currentLtp),
                                                          style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      children: [
                                                        const Text('P&L %', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          '${isPos ? "+" : ""}${holdingPnlPct.toStringAsFixed(2)}%',
                                                          style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.bold),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
            );
          },
        );
      },
    );
  }
}
