import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../features/holdings/bloc/holdings_bloc.dart';
import '../features/holdings/pages/holdings_page.dart';
import '../features/holdings/pages/orders_wallet_page.dart';
import '../features/market/bloc/market_bloc.dart';
import '../features/market/pages/market_page.dart';
import '../features/watchlist/bloc/watchlist_bloc.dart';
import '../features/watchlist/pages/watchlist_page.dart';
import '../injection_container.dart';
import 'theme/app_theme.dart';

class TradingApp extends StatelessWidget {
  const TradingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<MarketBloc>(
          create: (context) => sl<MarketBloc>(),
        ),
        BlocProvider<WatchlistBloc>(
          create: (context) => sl<WatchlistBloc>(),
        ),
        BlocProvider<HoldingsBloc>(
          create: (context) => sl<HoldingsBloc>(),
        ),
      ],
      child: MaterialApp(
        title: 'Trading Simulator',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        home: const MainNavigationShell(),
      ),
    );
  }
}

class MainNavigationShell extends StatefulWidget {
  const MainNavigationShell({super.key});

  @override
  State<MainNavigationShell> createState() => _MainNavigationShellState();
}

class _MainNavigationShellState extends State<MainNavigationShell> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    WatchlistPage(),
    MarketPage(),
    HoldingsPage(),
    OrdersWalletPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1E293B),
          border: Border(top: BorderSide(color: Color(0xFF334155), width: 0.5)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          backgroundColor: const Color(0xFF1E293B),
          selectedItemColor: const Color(0xFF3B82F6),
          unselectedItemColor: const Color(0xFF64748B),
          type: BottomNavigationBarType.fixed,
          selectedFontSize: 12,
          unselectedFontSize: 12,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.show_chart),
              activeIcon: Icon(Icons.show_chart, color: Color(0xFF3B82F6)),
              label: 'Watchlist',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.bolt),
              activeIcon: Icon(Icons.bolt, color: Color(0xFFF59E0B)),
              label: 'Markets',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.pie_chart),
              activeIcon: Icon(Icons.pie_chart, color: Color(0xFF10B981)),
              label: 'Holdings',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet),
              activeIcon: Icon(Icons.account_balance_wallet, color: Color(0xFF3B82F6)),
              label: 'Wallet',
            ),
          ],
        ),
      ),
    );
  }
}
