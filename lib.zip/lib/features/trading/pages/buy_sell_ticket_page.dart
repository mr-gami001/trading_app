import 'package:decimal/decimal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/constants/stock_constants.dart';
import '../../../core/utils/decimal_utils.dart';
import '../../../core/utils/validation_utils.dart';
import '../../../domain/entities/stock_quote.dart';
import '../../../domain/entities/trade_order.dart';
import '../../../injection_container.dart';
import '../../holdings/bloc/holdings_bloc.dart';
import '../../holdings/bloc/holdings_event.dart';
import '../../holdings/bloc/holdings_state.dart';
import '../../market/bloc/market_bloc.dart';
import '../../market/bloc/market_state.dart';
import '../bloc/trading_bloc.dart';
import '../bloc/trading_event.dart';
import '../bloc/trading_state.dart';

class BuySellTicketPage extends StatelessWidget {
  final String initialSymbol;
  final OrderSide initialSide;

  const BuySellTicketPage({
    super.key,
    required this.initialSymbol,
    this.initialSide = OrderSide.buy,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider<TradingBloc>(
      create: (context) => sl<TradingBloc>(),
      child: _BuySellTicketForm(
        initialSymbol: initialSymbol,
        initialSide: initialSide,
      ),
    );
  }
}

class _BuySellTicketForm extends StatefulWidget {
  final String initialSymbol;
  final OrderSide initialSide;

  const _BuySellTicketForm({
    required this.initialSymbol,
    required this.initialSide,
  });

  @override
  State<_BuySellTicketForm> createState() => _BuySellTicketFormState();
}

class _BuySellTicketFormState extends State<_BuySellTicketForm> {
  late String _selectedSymbol;
  late OrderSide _side;
  final TextEditingController _quantityController = TextEditingController(text: '1');

  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _selectedSymbol = widget.initialSymbol;
    _side = widget.initialSide;
  }

  @override
  void dispose() {
    _quantityController.dispose();
    super.dispose();
  }

  void _validateAndSubmit(StockQuote quote, HoldingsState holdingsState) {
    setState(() => _errorMessage = null);

    final rawQty = _quantityController.text.trim();
    final qtyVal = ValidationUtils.validateOrderQuantity(rawQty);
    if (!qtyVal.isValid) {
      setState(() => _errorMessage = qtyVal.errorMessage);
      return;
    }

    final int quantity = int.parse(rawQty);
    final Decimal qtyDecimal = Decimal.fromInt(quantity);
    final Decimal projectedValue = qtyDecimal * quote.ltp;

    if (_side == OrderSide.buy) {
      final buyVal = ValidationUtils.validateBuyOrder(
        walletBalance: holdingsState.walletBalance,
        orderValue: projectedValue,
      );
      if (!buyVal.isValid) {
        setState(() => _errorMessage = buyVal.errorMessage);
        return;
      }
    } else {
      final holding = holdingsState.getHoldingForSymbol(_selectedSymbol);
      final heldQty = holding?.quantity ?? 0;
      final sellVal = ValidationUtils.validateSellOrder(
        heldQuantity: heldQty,
        sellQuantity: quantity,
        symbol: _selectedSymbol,
      );
      if (!sellVal.isValid) {
        setState(() => _errorMessage = sellVal.errorMessage);
        return;
      }
    }

    // Submit Order with latest execution LTP
    context.read<TradingBloc>().add(
          ExecuteOrderEvent(
            symbol: _selectedSymbol,
            side: _side,
            quantity: quantity,
            ltp: quote.ltp,
          ),
        );
  }

  void _showConfirmationDialog(TradingSuccess successState) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(
              successState.side == OrderSide.buy ? Icons.check_circle : Icons.sell,
              color: successState.side == OrderSide.buy ? const Color(0xFF10B981) : const Color(0xFF3B82F6),
              size: 28,
            ),
            const SizedBox(width: 10),
            Text(
              '${successState.side == OrderSide.buy ? "BUY" : "SELL"} Executed!',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailRow('Stock', successState.symbol),
            _buildDetailRow('Quantity', '${successState.quantity} shares'),
            _buildDetailRow('Execution Price', DecimalUtils.formatCurrency(successState.executionPrice)),
            const Divider(color: Color(0xFF334155)),
            _buildDetailRow('Total Amount', DecimalUtils.formatCurrency(successState.totalValue), isBold: true),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B82F6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Done', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isBuy = _side == OrderSide.buy;
    final primaryColor = isBuy ? const Color(0xFF10B981) : const Color(0xFFEF4444);

    return BlocListener<TradingBloc, TradingState>(
      listener: (context, state) {
        if (state is TradingSuccess) {
          // Trigger portfolio refresh
          context.read<HoldingsBloc>().add(LoadPortfolioEvent());
          _showConfirmationDialog(state);
        } else if (state is TradingFailure) {
          setState(() => _errorMessage = state.errorMessage);
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1E293B),
          elevation: 0,
          title: Text(
            'Trade $_selectedSymbol',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Stock Selector Dropdown
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E293B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF334155)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: _selectedSymbol,
                          dropdownColor: const Color(0xFF1E293B),
                          icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                          items: StockConstants.supportedStocks.map((stock) {
                            return DropdownMenuItem<String>(
                              value: stock.symbol,
                              child: Text(
                                '${stock.symbol} - ${stock.name}',
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() {
                                _selectedSymbol = val;
                                _errorMessage = null;
                              });
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Live Price & Form Tile via BlocSelector
              BlocSelector<MarketBloc, MarketState, StockQuote?>(
                selector: (state) => state.quotes[_selectedSymbol],
                builder: (context, quote) {
                  if (quote == null) return const SizedBox.shrink();

                  return BlocBuilder<HoldingsBloc, HoldingsState>(
                    builder: (context, holdingsState) {
                      final int qty = int.tryParse(_quantityController.text.trim()) ?? 0;
                      final Decimal qtyDecimal = Decimal.fromInt(qty);
                      final Decimal estimatedTotal = qtyDecimal * quote.ltp;

                      return BlocBuilder<TradingBloc, TradingState>(
                        builder: (context, tradingState) {
                          final isSubmitting = tradingState is TradingSubmitting;

                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // LTP Banner
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E293B),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Live Price (LTP)',
                                          style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          DecimalUtils.formatCurrency(quote.ltp),
                                          style: TextStyle(
                                            color: quote.change >= Decimal.zero ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                                            fontSize: 22,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        const Text(
                                          'Day Change',
                                          style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          DecimalUtils.formatPriceChange(quote.change, quote.changePercent),
                                          style: TextStyle(
                                            color: quote.change >= Decimal.zero ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // Buy / Sell Side Selector Toggle
                              Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E293B),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () => setState(() {
                                          _side = OrderSide.buy;
                                          _errorMessage = null;
                                        }),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(vertical: 12),
                                          decoration: BoxDecoration(
                                            color: isBuy ? const Color(0xFF10B981) : Colors.transparent,
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: const Center(
                                            child: Text(
                                              'BUY',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () => setState(() {
                                          _side = OrderSide.sell;
                                          _errorMessage = null;
                                        }),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(vertical: 12),
                                          decoration: BoxDecoration(
                                            color: !isBuy ? const Color(0xFFEF4444) : Colors.transparent,
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          child: const Center(
                                            child: Text(
                                              'SELL',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 20),

                              // Input Quantity Field
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E293B),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'Quantity',
                                      style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        IconButton(
                                          onPressed: () {
                                            final current = int.tryParse(_quantityController.text) ?? 1;
                                            if (current > 1) {
                                              _quantityController.text = (current - 1).toString();
                                              setState(() {});
                                            }
                                          },
                                          icon: const Icon(Icons.remove_circle_outline, color: Colors.white),
                                        ),
                                        Expanded(
                                          child: TextField(
                                            controller: _quantityController,
                                            keyboardType: TextInputType.number,
                                            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            decoration: const InputDecoration(
                                              border: InputBorder.none,
                                              hintText: 'Qty',
                                              hintStyle: TextStyle(color: Color(0xFF64748B)),
                                            ),
                                            onChanged: (_) => setState(() => _errorMessage = null),
                                          ),
                                        ),
                                        IconButton(
                                          onPressed: () {
                                            final current = int.tryParse(_quantityController.text) ?? 0;
                                            _quantityController.text = (current + 1).toString();
                                            setState(() {});
                                          },
                                          icon: const Icon(Icons.add_circle_outline, color: Colors.white),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // Order Summary & Balance Check Info
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E293B),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text('Projected Order Value', style: TextStyle(color: Color(0xFF94A3B8))),
                                        Text(
                                          DecimalUtils.formatCurrency(estimatedTotal),
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          isBuy ? 'Available Wallet Balance' : 'Shares Currently Held',
                                          style: const TextStyle(color: Color(0xFF94A3B8)),
                                        ),
                                        Text(
                                          isBuy
                                              ? DecimalUtils.formatCurrency(holdingsState.walletBalance)
                                              : '${holdingsState.getHoldingForSymbol(_selectedSymbol)?.quantity ?? 0} shares',
                                          style: TextStyle(
                                            color: isBuy && holdingsState.walletBalance < estimatedTotal
                                                ? const Color(0xFFEF4444)
                                                : Colors.white,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // Inline Error Banner
                              if (_errorMessage != null)
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: const Color(0x22EF4444),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: const Color(0xFFEF4444)),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 20),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          _errorMessage!,
                                          style: const TextStyle(color: Color(0xFFEF4444), fontSize: 13),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              const SizedBox(height: 24),

                              // Submit Button
                              SizedBox(
                                width: double.infinity,
                                height: 52,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: primaryColor,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                  onPressed: isSubmitting ? null : () => _validateAndSubmit(quote, holdingsState),
                                  child: isSubmitting
                                      ? const SizedBox(
                                          height: 24,
                                          width: 24,
                                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                                        )
                                      : Text(
                                          'Submit ${isBuy ? "BUY" : "SELL"} Order',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                ),
                              ),
                            ],
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
