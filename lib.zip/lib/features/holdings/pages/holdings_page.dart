import 'package:decimal/decimal.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/utils/decimal_utils.dart';
import '../../../domain/usecases/holdings/get_portfolio_summary_usecase.dart';
import '../../../injection_container.dart';
import '../../market/bloc/market_bloc.dart';
import '../../market/bloc/market_state.dart';
import '../../trading/pages/buy_sell_ticket_page.dart';
import '../bloc/holdings_bloc.dart';
import '../bloc/holdings_event.dart';
import '../bloc/holdings_state.dart';
import '../widgets/portfolio_summary_card.dart';

class HoldingsPage extends StatelessWidget {
  const HoldingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final summaryUseCase = sl<GetPortfolioSummaryUseCase>();

    return BlocBuilder<MarketBloc, MarketState>(
      builder: (context, feedState) {
        return BlocBuilder<HoldingsBloc, HoldingsState>(
          builder: (context, holdingsState) {
            final quotes = feedState.quotes;
            final holdings = holdingsState.getSortedHoldings(quotes);
            final summary = summaryUseCase.execute(
              holdings: holdingsState.holdings,
              quotes: quotes,
            );

            return Scaffold(
              backgroundColor: const Color(0xFF0F172A),
              appBar: AppBar(
                backgroundColor: const Color(0xFF1E293B),
                elevation: 0,
                title: const Row(
                  children: [
                    Icon(Icons.pie_chart, color: Color(0xFF10B981)),
                    SizedBox(width: 8),
                    Text(
                      'Portfolio Holdings',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              body: holdingsState.isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : Column(
                      children: [
                        // Portfolio Summary Banner Card
                        PortfolioSummaryCard(summary: summary),

                        // Filter / Sort Options Header Bar
                        if (holdings.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Holdings (${holdings.length})',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                Row(
                                  children: [
                                    const Text('Sort by: ', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
                                    DropdownButtonHideUnderline(
                                      child: DropdownButton<HoldingSortOption>(
                                        value: holdingsState.sortOption,
                                        dropdownColor: const Color(0xFF1E293B),
                                        style: const TextStyle(color: Color(0xFF3B82F6), fontWeight: FontWeight.bold, fontSize: 12),
                                        icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF3B82F6)),
                                        items: const [
                                          DropdownMenuItem(
                                            value: HoldingSortOption.pnlDesc,
                                            child: Text('P&L (High to Low)'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.pnlAsc,
                                            child: Text('P&L (Low to High)'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.currentValueDesc,
                                            child: Text('Current Value'),
                                          ),
                                          DropdownMenuItem(
                                            value: HoldingSortOption.symbolAsc,
                                            child: Text('Symbol (A-Z)'),
                                          ),
                                        ],
                                        onChanged: (val) {
                                          if (val != null) {
                                            context.read<HoldingsBloc>().add(SetSortOptionEvent(val));
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                        // Holdings List or Empty State
                        Expanded(
                          child: holdings.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Icon(Icons.account_balance_wallet_outlined, size: 64, color: Color(0xFF475569)),
                                      const SizedBox(height: 16),
                                      const Text(
                                        'No holdings in your portfolio',
                                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                                      ),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Buy stocks from the Watchlist or Live Market to start',
                                        style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
                                      ),
                                    ],
                                  ),
                                )
                              : ListView.builder(
                                  itemCount: holdings.length,
                                  itemBuilder: (context, index) {
                                    final holding = holdings[index];
                                    final quote = quotes[holding.symbol];
                                    final Decimal currentLtp = quote?.ltp ?? holding.avgCost;
                                    final Decimal holdingPnl = holding.pnl(currentLtp);
                                    final Decimal holdingPnlPct = holding.pnlPercent(currentLtp);
                                    final bool isPos = holdingPnl >= Decimal.zero;
                                    final Color color = isPos ? const Color(0xFF10B981) : const Color(0xFFEF4444);

                                    return Container(
                                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF1E293B),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: const Color(0xFF334155)),
                                      ),
                                      child: Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          borderRadius: BorderRadius.circular(12),
                                          onTap: () {
                                            Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) => BuySellTicketPage(initialSymbol: holding.symbol),
                                              ),
                                            );
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(14.0),
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Text(
                                                          holding.symbol,
                                                          style: const TextStyle(
                                                            color: Colors.white,
                                                            fontWeight: FontWeight.bold,
                                                            fontSize: 16,
                                                          ),
                                                        ),
                                                        const SizedBox(width: 8),
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xFF334155),
                                                            borderRadius: BorderRadius.circular(4),
                                                          ),
                                                          child: Text(
                                                            'Qty: ${holding.quantity}',
                                                            style: const TextStyle(color: Color(0xFFCBD5E1), fontSize: 11),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Text(
                                                      DecimalUtils.formatCurrency(holdingPnl),
                                                      style: TextStyle(
                                                        color: color,
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 10),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        const Text('Avg. Cost', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          DecimalUtils.formatCurrency(holding.avgCost),
                                                          style: const TextStyle(color: Colors.white, fontSize: 13),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        const Text('LTP', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          DecimalUtils.formatCurrency(currentLtp),
                                                          style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600),
                                                        ),
                                                      ],
                                                    ),
                                                    Column(
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      children: [
                                                        const Text('P&L %', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11)),
                                                        Text(
                                                          '${isPos ? "+" : ""}${holdingPnlPct.toDouble().toStringAsFixed(2)}%',
                                                          style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.bold),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
            );
          },
        );
      },
    );
  }
}
